

app.service('httpService',function ($http) {

    this.getUserList=function () {
        var url='https://jsonplaceholder.typicode.com/users';
        return $http.get(url).then(function(response) {
            return response.data;
        });
    }


    this.getUserDetails=function (id) {
        var url='https://jsonplaceholder.typicode.com/todos?userId='+id;
        return $http.get(url).then(function(response) {
            return response.data;
        });
    }

});