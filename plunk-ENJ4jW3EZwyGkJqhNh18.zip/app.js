

var app=angular.module('app',['ui.router']);

app.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/list');

    $stateProvider
        .state('list', {
            url: '/list',
            templateUrl: 'user-list.html',
            controller:'userListController'
        })
        .state('userDetails', {
            url: '/userDetails/:id',
            templateUrl: 'user-details.html',
            controller:'userDetailsController',
            resolve:{
                userDetails:function ($stateParams,httpService) {
                    return httpService.getUserDetails($stateParams.id).then(function (response) {
                        return response;
                    })
                }
            }
        });


});

