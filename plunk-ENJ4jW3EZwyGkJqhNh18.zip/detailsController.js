

app.controller('userDetailsController',function ($scope,$state,$stateParams,httpService,userDetails) {

    $scope.userDetails=userDetails;

    $scope.save=function () {
        if($scope.title) {
            var obj = {
                id: $scope.userDetails.length + 1,
                title: $scope.title,
                completed: false
            }
            $scope.userDetails.push(obj);
            $scope.title = "";
        }
    }

    $scope.delete=function(index)
    {
      $scope.userDetails.splice(index,1); 
    }
    $scope.back=function(){
      $state.go('list');
    }

});
