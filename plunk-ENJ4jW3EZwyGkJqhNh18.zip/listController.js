

app.controller('userListController',function ($scope,$state,httpService) {

    $scope.userList={};
    httpService.getUserList().then(function (response) {
        $scope.userList=response;
        console.log(response);
    });

    $scope.view=function (id) {
        var params={
            id:id
        }
        $state.go('userDetails',params);
    }
    $scope.delete=function (id) {
        $scope.userList.splice(id,1)
    }

});



